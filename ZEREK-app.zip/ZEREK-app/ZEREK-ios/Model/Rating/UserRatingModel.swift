//
//  RatingModel.swift
//  ZEREK
//

import Foundation

struct UserRatingModel: Identifiable {
    let id = UUID()
    let rank: Int
    let name: String
    let photo: String
    let score: Int
}
