//
//  RegistryModel.swift
//

import SwiftUI

struct RegistryModel {
    var oldYear: String
    var level: String
    var purpose: String
    var email: String
    var password: String
    var firstName: String
    var lastName: String
    
}
