//
//  UnitModel.swift
//

import SwiftUI
import FirebaseFirestore

struct UnitModel: Identifiable {
    let id: UUID = UUID()
    let title: Int
    let description: String
    let levels: [LevelModel]
    let imageName: String
}

struct UnitTest: Identifiable, Codable {
    var id = UUID()
    var title: String
    var questions: [String]
}
