//
//  ZEREK_iosApp.swift
//

import SwiftUI
import FirebaseCore

class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        FirebaseApp.configure()
        
        return true
    }
}

@main
struct ZEREK_iosApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    @ObservedObject var navigation = Navigation()
    @ObservedObject var registryViewModel: RegistryViewModel = RegistryViewModel.shared
    @ObservedObject var mainViewModel: MainViewModel = MainViewModel()
    
    var body: some Scene {
        WindowGroup {
            NavigationStack(path: $navigation.navPath) {
                TabBarView()
                    .navigationDestination(for: Navigation.Destination.self) { destination in
                        destination.getView()
                    }
            }
            .environmentObject(navigation)
            .environmentObject(registryViewModel)
            .environmentObject(mainViewModel)
        }
    }
}
