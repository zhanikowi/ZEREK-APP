//
//  Int + extension.swift
//

import SwiftUI

extension Int {
    var toString: String {
        return "\(self)"
    }
}
