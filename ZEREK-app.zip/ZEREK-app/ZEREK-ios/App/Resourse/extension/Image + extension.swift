//
//  Image + extension.swift
//

import SwiftUI

extension Image {
    var configure: some View {
        self
            .resizable()
            .scaledToFit()
    }
}
