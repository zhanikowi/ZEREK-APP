//
//  WelcomeView.swift
//

import SwiftUI

struct WelcomeView: View {
    @EnvironmentObject var navigation: Navigation
    
    var body: some View {
        VStack {
            RoundedRectangle(cornerRadius: 1)
                .frame(maxWidth: .infinity, maxHeight: 64)
                .foregroundColor(Color(red: 125/255, green: 128/255, blue: 218/255))
                .ignoresSafeArea()
            Spacer()
            
            Constant.getText(text: "Welcome to Zerek", font: .bold, size: 22)
                .padding(.bottom)
                        
            Image("1")
                .resizable()
                .scaledToFit()
                .frame(maxWidth: UIScreen.main.bounds.width * 0.77)
            
            Button(action: {
                navigation.navigate(to: .selectAge)
            }, label: {
                Text("Continue")
                    .padding()
                    .frame(maxWidth: .infinity)
                    .foregroundColor(.white)
                    .background(Color(red: 91/255, green: 123/255, blue: 254/255))
                    .cornerRadius(12)
                    .padding()
            })
            Spacer()
        }
    }
}

#Preview {
    WelcomeView()
}
