//
//  ServerManager.swift
//  ZEREK-ios
//

import SwiftUI
import Firebase
import FirebaseAuth

final class ServerManager {
    private init() {}
    
    static func signUp(email: String, password: String, user: UserModel) async throws -> UserModel?{
        
        let authDataResult = try await Auth.auth().createUser(withEmail: email, password: password)
        
        let changeRequest = authDataResult.user.createProfileChangeRequest()
        changeRequest.displayName = user.firstName
        
        do {
            try await changeRequest.commitChanges()
            print(authDataResult.user.displayName ?? "Loading name .....")
            
            return user
        } catch {
            throw error
        }
    }
    
    @discardableResult
    static func login(email: String, password: String) async throws -> UserModel? {
        let authDataResult = try await Auth.auth().signIn(withEmail: email, password: password)
        
        guard let userEmail = authDataResult.user.email,
              let user = try await fetchUser(email: userEmail)
        else {
            print("returned nil")
            return nil
        }
        
        return user
    }
    
    @discardableResult
    static func getAuthenticatedUser() throws -> UserModel? {
        guard let user = Auth.auth().currentUser
        else {
            return nil
        }
        return UserModel(id: "", firstName: "", lastName: "", email: "", languageLevel: "", age: "", purpose: "")
    }
    
    public static func fetchUser(email: String) async throws -> UserModel? {
        let db = Firestore.firestore()
        
        let querySnapshot = try await db.collection("users")
            .whereField("email", isEqualTo: email)
            .getDocuments()
        
        guard let firstDocument = querySnapshot.documents.first else {
            print("User not found!")
            return nil
        }
        print("Data:", firstDocument.data())
        return UserModel(dictionary: firstDocument.data())
    }
    
    
    public static func signOut() throws {
        try Auth.auth().signOut()
    }
    
    
    static func resentPassword(email: String) async throws {
        try await Auth.auth().sendPasswordReset(withEmail: email)
    }
    
    static func updatePassword(password: String) async throws{
        guard let user = Auth.auth().currentUser else {
            throw URLError(.badServerResponse)
        }
        
        try await user.updatePassword(to: password)
    }
    
    static func createNewUser(userInfo: UserModel) async throws {
        let userData: [String: Any] = [
            "id": userInfo.id,
            "firstName": userInfo.firstName,
            "lastName": userInfo.lastName,
            "email" : userInfo.email,
            "age": userInfo.age,
            "languageLevel" : userInfo.languageLevel,
            "purpose" : userInfo.purpose
        ]
        
        try await Firestore.firestore().collection("users").document(userInfo.email).setData(userData,merge: false)
    }
    
    private static let db = Firestore.firestore()
    
    static func fetchUnit(unitID: String, completion: @escaping ([[UnitTest]]) -> Void) {
        db.collection(unitID).getDocuments { snapshot, error in
            if let error = error {
                print("Қате: \(error.localizedDescription)")
                completion([])
                return
            }
            
            guard let documents = snapshot?.documents else {
                print("Құжаттар табылмады.")
                completion([])
                return
            }
            
            var unit: [[UnitTest]] = []
            
            for document in documents {
                if let data = document.data() as? [String: [String]] {
                    let unitList: [UnitTest] = data.map { (key, value) in
                        UnitTest(title: key, questions: value)
                    }
                    unit.append(unitList)
                }
            }
            completion(unit)
        }
    }
    
    public static func fetchUser(completion: @escaping (UserModel?) -> Void) {
        guard let email = Auth.auth().currentUser?.email else {
            completion(nil)
            return
        }
        
        let db = Firestore.firestore()
            db.collection("users").whereField("email", isEqualTo: email).getDocuments { snapshot, error in
                if let error = error {
                    print("Error fetching user: \(error)")
                    completion(nil)
                    return
                }

                guard let document = snapshot?.documents.first else {
                    completion(nil)
                    return
                }

                do {
                    let user = try document.data(as: UserModel.self)
                    completion(user)
                } catch {
                    print("Error decoding user: \(error)")
                    completion(nil)
                }
            }
    }
    
    static func updateUserData(firstName: String?, lastName: String?, newPassword: String?, completion: @escaping (Result<UserModel, Error>) -> Void) {
        guard let user = Auth.auth().currentUser else {
            completion(.failure(NSError(domain: "No user", code: 401)))
            return
        }
        
        guard let userEmail = user.email else {
            completion(.failure(NSError(domain: "No user", code: 401)))
            return
        }

        let db = Firestore.firestore()
        let userRef = db.collection("users").document(userEmail)
        var updatedFields: [String: Any] = [:]

        if let firstName = firstName, !firstName.isEmpty {
            updatedFields["firstName"] = firstName
        }

        if let lastName = lastName, !lastName.isEmpty {
            updatedFields["lastName"] = lastName
        }

        func fetchAndReturnUser() {
            userRef.getDocument { document, error in
                if let document = document, let data = document.data(), let userModel = UserModel(dictionary: data) {
                    completion(.success(userModel))
                } else {
                    completion(.failure(error ?? NSError(domain: "Failed to fetch user", code: 500)))
                }
            }
        }

        if !updatedFields.isEmpty {
            userRef.updateData(updatedFields) { error in
                if let error = error {
                    completion(.failure(error))
                    return
                }

                if let newPassword = newPassword, !newPassword.isEmpty {
                    user.updatePassword(to: newPassword) { error in
                        if let error = error {
                            completion(.failure(error))
                        } else {
                            fetchAndReturnUser()
                        }
                    }
                } else {
                    fetchAndReturnUser()
                }
            }
        } else if let newPassword = newPassword, !newPassword.isEmpty {
            user.updatePassword(to: newPassword) { error in
                if let error = error {
                    completion(.failure(error))
                } else {
                    fetchAndReturnUser()
                }
            }
        } else {
            fetchAndReturnUser()
        }
    }

}
